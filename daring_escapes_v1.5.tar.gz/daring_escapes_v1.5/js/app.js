'use strict';

(function() {

    var app = angular.module('daring-escapes', ['ngRoute', 'ngAnimate', 'routeStyles', 'main-ctrl']);

    app.config(function($routeProvider) {
        $routeProvider
            .when('/', {
                templateUrl: 'partials/home/index.html',
                css: ['partials/home/style.css']
            })
            .when('/about', {
                templateUrl: 'partials/about/index.html',
                css: ['partials/about/style.css']
            })
            .when('/bookyourescape', {
                templateUrl: 'partials/bookyourescape/index.html',
                css: ['partials/bookyourescape/style.css']
            })
            .when('/faq', {
                templateUrl: 'partials/faq/index.html',
                css: ['partials/faq/style.css']
            })
            .when('/contactus', {
                templateUrl: 'partials/contactus/index.html',
                css: ['partials/contactus/style.css']
            })
            .when('/bookyourescape/pittsburgh', {
                templateUrl: 'partials/bookyourescape/locations/pittsburgh.html',
                css: ['partials/contactus/style.css']
            })
            .otherwise({
                redirectTo: '/'
            });
    });

})();