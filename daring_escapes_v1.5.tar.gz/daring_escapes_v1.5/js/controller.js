'use strict';

(function() {
    var app = angular.module('main-ctrl', []);

    app.controller('NavController', function($scope, $location) {
        $scope.navbarCollapsed = true;
    });

})();