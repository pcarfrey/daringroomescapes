$(document).ready(function() {
    $(".exit-off-canvas-mod").click(function() {
        $(".off-canvas-wrap").removeClass("move-left");
    });
});